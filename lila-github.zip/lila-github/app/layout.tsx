import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'Lila · Mi bolsillo',description:'Tus gastos, metas y cuentas compartidas en un solo lugar.',icons:{icon:'/favicon.svg',apple:'/icon-180.png'},manifest:'/manifest.webmanifest',appleWebApp:{capable:true,title:'Lila',statusBarStyle:'default'}};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="es"><head><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/><meta name="theme-color" content="#79556f"/></head><body>{children}</body></html>}
