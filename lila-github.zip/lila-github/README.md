# Lila · Mi bolsillo

App personal de gastos diseñada para iPhone, con la misma interfaz de la primera versión de Lila.

- Gastos y saldo disponible del mes.
- Resumen de hoy, semana, mes e histórico.
- Sueldo y distribución porcentual editables.
- Metas y aportes de ahorro.
- Cuenta temporal por persona con propina ajustable y comprobante JPG.

## Publicación gratuita en GitHub Pages

1. Sube este proyecto a un repositorio público de tu cuenta.
2. En **Settings → Pages → Build and deployment → Source**, elige **GitHub Actions**.
3. Ejecuta **Actions → Publicar Lila → Run workflow** o sube un cambio a `main`.
4. Cuando termine, la dirección estará en **Settings → Pages**.

No requiere Sites, servidor propio, dominio comprado ni claves de API. Usa rutas relativas, por lo que funciona dentro de la dirección de un repositorio.

## En iPhone

Abre la dirección publicada en Safari, toca Compartir y Agregar a inicio. La app necesita conexión para cargar; no ofrece funcionamiento sin conexión.

## Datos

Los datos se guardan en el navegador y dispositivo que usas (`localStorage`). No se envían a GitHub, no se sincronizan entre dispositivos y se pierden si borras los datos del navegador. En un mismo dominio, otras páginas de ese dominio pueden acceder al almacenamiento del navegador. No subas tus registros ni tu sueldo al repositorio.

La cuenta compartida no se conserva al recargar. Se limpia después de compartir o descargar su JPG. Los aportes a metas representan dinero ya ahorrado; no se descuentan de nuevo como gastos.

## Desarrollo

Node.js 24 y pnpm 11.19.0:

```sh
pnpm install --frozen-lockfile --ignore-scripts
pnpm dev
pnpm build
```

La publicación utiliza solamente `dist/`. No hay conexión con bancos ni funciones de pago.
