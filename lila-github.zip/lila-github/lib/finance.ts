export function splitBill(people:string[],items:{person:string;amount:number}[],tip:number){
 const total=items.reduce((a,b)=>a+b.amount,0),tipTotal=Math.round(total*tip/100);
 const rows=people.map(person=>{const subtotal=items.filter(i=>i.person===person).reduce((a,b)=>a+b.amount,0);const raw=total?subtotal/total*tipTotal:0;return {person,subtotal,tip:Math.floor(raw),remainder:raw-Math.floor(raw)};});
 let left=tipTotal-rows.reduce((s,p)=>s+p.tip,0);
 for(const row of [...rows].sort((a,b)=>b.remainder-a.remainder)){if(left<=0)break;if(row.subtotal>0){row.tip++;left--;}}
 return rows.map(p=>({...p,total:p.subtotal+p.tip}));
}
